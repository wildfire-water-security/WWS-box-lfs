#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom fs path_home
#' @importFrom rlang is_interactive
#' @importFrom tools file_path_sans_ext
#' @importFrom utils unzip
#' @importFrom withr local_tempdir
## usethis namespace: end
NULL
