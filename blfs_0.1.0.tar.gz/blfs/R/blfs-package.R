#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom fs path_home
#' @importFrom tools file_path_sans_ext
## usethis namespace: end
NULL
